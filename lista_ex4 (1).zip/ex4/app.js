const http = require('http');


const server = http.createServer((req,res)=>{

const objeto = {
    url:req.url,
    //parametros: req.
    metodo: req.method
};

console.log(objeto);

res.end();
} );

server.listen(3000);