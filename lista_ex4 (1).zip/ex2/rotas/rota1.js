const express = require('express');

const router = express.Router();

const path = require('path');

const lista = [];


//get pois so envia dados
router.get('/', (req, res)=>{
    res.sendFile(path.join(__dirname, '../', 'h1.html'));
});

//get pois so envia dados
router.get('/usuario', (req, res)=>{
    res.sendFile(path.join(__dirname, '../', 'usuario.html'));
});

//post pois faz uso dos dados
router.post('/usuario/cadastrar', (req, res)=>{
    lista.push(req.body.nome);
    res.send(lista);
});

router.get('*', (req, res)=>{
    res.statusCode = 404;
    res.send('<a href="/"> voltar </a>');
});

 
module.exports = router;

