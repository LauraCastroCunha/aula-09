
const express = require('express');

const app = express();

const rotas = require('./rotas/rota1');

app.use(express.urlencoded({extended: true}));

app.use(rotas);


app.listen(3000);


