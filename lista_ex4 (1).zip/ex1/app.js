
const http = require('http');

const server = http.createServer((req, resp)=>{

    resp.write("<h1> ok, sua url:"+req.url+" </h1>");

});

server.listen(3000);